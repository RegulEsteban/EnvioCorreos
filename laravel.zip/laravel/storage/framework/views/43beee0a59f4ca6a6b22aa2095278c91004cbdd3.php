<h1>Hola <?php echo e($name); ?></h1>
l<p>Ya hazle caso a Esteban.</p><?php /**PATH C:\Users\regul\Documents\PHP\laravel\resources\views/mail.blade.php ENDPATH**/ ?>
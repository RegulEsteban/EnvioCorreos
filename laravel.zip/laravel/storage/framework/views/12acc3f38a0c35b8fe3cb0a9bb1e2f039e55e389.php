<!doctype html>
<html>
   <body>
    <!--
     <input type='text' id='search' name='search' placeholder='Email'>
   -->
     <br/>
     <input type='button' value='Validar contratos' id='but_fetchall'>
     <br/>
     <table border='1' id='userTable' style='border-collapse: collapse;'>
       <thead>
        <tr>
          <th>IdCto</th>
          <th>Cto</th>
          <th>Fecha Inicio</th>
          <th>Fecha Ven</th>
        </tr>
       </thead>
       <tbody></tbody>
     </table>

     <!-- Script -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> <!-- jQuery CDN -->

     <script type='text/javascript'>
     $(document).ready(function(){

       // Fetch all records
       $('#but_fetchall').click(function(){
	       fetchRecords($('#search').val());
       });

     });

     function fetchRecords(id){
       $.ajax({
         //url: 'getContratos/'+id,
         url: 'getContratos/2019-01-10',
         type: 'get',
         dataType: 'json',
         success: function(response){
console.log(response);

           var len = 0;
           $('#userTable tbody').empty(); // Empty <tbody>
           if(response['data'] != null){
             len = response['data'].length;
           }

           if(len > 0){
             for(var i=0; i<len; i++){
               var id = response['data'][i].id_contrato;
               var username = response['data'][i].contrato;
               var name = response['data'][i].fecha_inicio;
               var email = response['data'][i].fecha_termino;

               var tr_str = "<tr>" +
                   "<td align='center'>" + (i+1) + "</td>" +
                   "<td align='center'>" + username + "</td>" +
                   "<td align='center'>" + name + "</td>" +
                   "<td align='center'>" + email + "</td>" +
               "</tr>";

               $("#userTable tbody").append(tr_str);
             }
           }else if(response['data'] != null){
              var tr_str = "<tr>" +
                  "<td align='center'>1</td>" +
                  "<td align='center'>" + response['data'].username + "</td>" + 
                  "<td align='center'>" + response['data'].name + "</td>" +
                  "<td align='center'>" + response['data'].email + "</td>" +
              "</tr>";

              $("#userTable tbody").append(tr_str);
           }else{
              var tr_str = "<tr>" +
                  "<td align='center' colspan='4'>No record found.</td>" +
              "</tr>";

              $("#userTable tbody").append(tr_str);
           }

         }
       });
     }
     </script>
  </body>
</html><?php /**PATH C:\Users\regul\Documents\PHP\laravel\resources\views/contratos.blade.php ENDPATH**/ ?>
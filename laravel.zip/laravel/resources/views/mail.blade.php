<h1>Hola {{ $name }}</h1>
l<p>Ya hazle caso a Esteban.</p>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Page;

use Datetime;
use Mail;

class PagesController extends Controller{
    public function index(){
    	return view('contratos');
  	}

  	public function getContratos($fecha = "2019-01-01"){
  		$data = array('name'=>"Arancita");
   
    	// Fetch all records
    	$userData['data'] = Page::getuserData(0);
    	$nowDate = new DateTime($fecha);

    	foreach ($userData['data'] as $key => $value) {
    		if (new DateTime($value ->{'fecha_termino'}) <= $nowDate) {

    			Mail::send('mail', $data, function($message) {
			        $message->to('al221710715@gmail.com', 'Tutorials Point')->subject('Titulo del correo');
			        $message->from('servicios@consultoriatdc.com','Aranza');
			    });
    		}
    	}

    	echo json_encode($userData);
    	exit;
  	}
}

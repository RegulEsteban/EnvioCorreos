<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Mail;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class MailController extends Controller {
   public function basic_email() {
      $data = array('name'=>"Arancita");
   
      Mail::send('mail', $data, function($message) {
         $message->to('regulesteban@gmail.com', 'Tutorials Point')->subject('Soy el amor de tu vida');
         $message->from('servicios@consultoriatdc.com','Esteban Regules');
      });
      echo "Basic Email Sent. Check your inbox.";
   }
}
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Page extends Model{
    public static function getuserData($id=0){

    	if($id==0){
      		$value=DB::table('contratos')->get(); 
    	}else{
      		$value=DB::table('contratos')->where('id_contrato', $id)->first();
    	}
    	return $value;
  	}
}
